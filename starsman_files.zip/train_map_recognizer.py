# -*- coding: utf-8 -*-
"""
Created on Tue Sep 27 15:35:11 2022

@author: scott
"""

import cv2
import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd
import json

with open('settings.json') as f:
    settings = json.load(f)
# The directory containing the tif and json files
sub_dir = settings['sub_dir']

directory = settings['base_dir'] + sub_dir + '/thumbnails/'

moments = {}
map_bounds = {}
for file in os.listdir(directory):
    #file = 'AK_Seldovia_thumb.tif'
    #file = file_b.decode('UTF-8')
    if file[-4:] == '.tif':
        print(file)
            
        img = cv2.imread(directory + file)
            
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        threshold = 240
        while True:
            _, th = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
            #plt.imshow(th)
            #plt.axis('off')
            #plt.show()
            contours, _ = cv2.findContours(th, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            #moments[file] = []
            draw_contours = []
            #areas = []
            largest_contour = None
            largest_contour_area = 0
            for contour in contours:
                moment = cv2.moments(contour)
                #moments[file].append(moment)
                #areas.append(moment['m00'])
                if moment['m00'] > 25000 and moment['m00'] < 160000:
                    draw_contours.append(contour)
                    if moment['m00'] > largest_contour_area:
                        largest_contour_area = moment['m00']
                        largest_contour = contour
            if len(draw_contours) == 0:
                threshold -= 10
                print(str(threshold))
            else:
                #all_draw_contours = np.concatenate(draw_contours)
                #p_min = np.min(all_draw_contours, axis=0)
                #p_max = np.max(all_draw_contours, axis=0)
                # Use largest contour 
                p_min = np.min(largest_contour, axis=0)
                p_max = np.max(largest_contour, axis=0)                
                # all_draw_contours = draw_contours[0]
                # if len(draw_contours) > 1:
                #     all_draw_contours = np.concatenate(draw_contours)
                break
            if threshold < 120:
                p_min = np.array(np.array(np.zeros((1, 2))).astype(np.int32))
                p_max = np.array(np.array(np.ones((1, 2)) * 511).astype(np.int32))
                break
        cv2.drawContours(img, draw_contours, -1, (255,0,0), 1)
        fig = plt.figure()
        ax = fig.add_subplot(111)
        plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        plt.text(256, 20, file[:15], color='red', ha='center', va='top')
        
        rect = patches.Rectangle(p_min[0], (p_max - p_min)[0][0], (p_max - p_min)[0][1], linewidth=1, edgecolor='g', facecolor='none')
        ax.add_patch(rect)
        for contour in draw_contours:
            moment = cv2.moments(contour)
            plt.text(moment['m10'] / moment['m00'], moment['m01'] / moment['m00'], str(int(moment['m00'])), va='center', ha='center')
        plt.axis('off')
        plt.savefig(directory + 'contours/' + file)
        map_bounds[file] = {'x0': p_min[0][0], 'x1':p_max[0][0], 'y0':p_min[0][1], 'y1':p_max[0][1]}
df = pd.DataFrame(map_bounds).transpose()
df = df / 512
df.to_csv('map_bounds_' + sub_dir + '.csv')

