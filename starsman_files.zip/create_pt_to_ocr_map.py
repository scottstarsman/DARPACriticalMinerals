# -*- coding: utf-8 -*-
"""
Created on Fri Nov  4 11:00:14 2022

@author: scott
"""
import cv2
import numpy as np
import time
from tensorflow import keras
import json
import pickle
import matplotlib.pyplot as plt
import os

def letter_box(img):
    temp = 255-img
    rows = np.any(temp, axis=0)
    cols = np.any(temp, axis=1)
    if np.any(rows == True):
        rmin, rmax = np.where(rows)[0][[0, -1]]
    else:
        rmin = 0 
        rmax = len(rows)
    if np.any(cols == True):
        cmin, cmax = np.where(cols)[0][[0, -1]]
    else:
        cmin = 0
        cmax = len(cols)
    return cmin, rmin, cmax + 1, rmax + 1

def rescale_character(image, height, width):
    y0, x0, y1, x1 = letter_box(image)
    image = image[y0: y1, x0:x1]
    im_height = image.shape[0]
    im_width = image.shape[1]
    if im_height > height or im_width > width:
        # too large 
        max_dim = max(im_height, im_width)
        sub_img = 255 * np.ones((max_dim, max_dim, 3), dtype=np.uint8)
        if im_height > im_width:
            offset = (im_height - im_width) // 2
            for k in range(3):
                sub_img[0:im_height, offset:offset + im_width, k] = image  
        else:
            offset = (im_width - im_height) // 2
            for k in range(3):
                sub_img[offset:offset + im_height, 0:im_width, k] = image
        sub_img = cv2.resize(sub_img, (16, 16), interpolation = cv2.INTER_AREA)
        #cv2.imwrite('parsed_text/' + str(ind) + '_failed.jpg', sub_img)
    else:
        x_offset = (width - im_width) // 2 
        y_offset = (height - im_height)  // 2
        sub_img = 255 * np.ones((height, width, 3), dtype=np.uint8)
        for k in range(3):
            sub_img[y_offset:y_offset + im_height, x_offset:x_offset + im_width, k] = image
    return sub_img

# This took 200 seconds on the validation data set
with open('settings.json') as f:
    settings = json.load(f)
# The directory containing the tif and json files
sub_dir = settings['sub_dir']

data_dir = settings['base_dir'] + sub_dir + '/'

width = 16
height = 16
conf_threshold = 75
min_conf = 0.5
debug = False
version = 'v7'

start_time = time.time()
directory = os.fsencode(data_dir)

# Build list of map names
maps = []
files = []
for file_b in os.listdir(directory):
    file = file_b.decode('UTF-8')
    files.append(file)
    if file[-4:] == 'json':
        maps.append(file[:-5])

# Load the OCR model and the label to output mapping
# v4 is 97_prod and 95, respectively
if version == 'v7':
    model_name = 'legend_recognition_16x16_97_prod.h5'
    labels_name = 'labels_95_prod.pkl'
else:
    model_name = 'legend_recognition_16x16_99_prod.h5'
    labels_name = 'labels_97.pkl'
model = keras.models.load_model(model_name)
with open(labels_name, 'rb') as fp:  
    labels = pickle.load(fp)
labels.append(' ')
    
# Retrieve the data from all the info files for each map and store it in data_files
data_files = {}
for cur_map in maps:
    data_files[cur_map] = {}
    map_files = [f for f in files if (f.startswith(cur_map) and len(f) > len(cur_map) + 5)]
    f = open(data_dir + cur_map + '.json', 'r')
    data_files[cur_map]['metadata'] = json.load(f)
    f.close()
    data_files[cur_map]['base_map'] = cur_map + '.tif'
    data_files[cur_map]['results'] = map_files

map_labels = {}
valid_legends = {}
for data_file in data_files:
    print(data_file)
    map_data = data_files[data_file]['metadata'] #json.load(f)
    img = cv2.imread(data_dir + data_file + '.tif')
    proc_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    proc_img = cv2.threshold(proc_img, 128, 255, cv2.THRESH_BINARY)[1]
    
    legends = []
    label_names = []
    legend_imgs = []
    legend_map = []
    pred_img = 255 * np.ones((len(map_data['shapes']), height, width, 3), dtype=np.uint8)
    k = 0
    for shape in map_data['shapes']:
        if shape['label'][-2:] == 'pt' or shape['label'][-5:] == 'point':
            print(shape['label'])
            label_names.append(shape['label'])
            legends.append(' '. join(shape['label'].split('_')[0:-1]))
            points = [[round(k) for k in tmp] for tmp in shape['points']]
            points = np.array(points)
            p_min = np.min(points, axis=0)
            p_max = np.max(points, axis=0)
            points = [[0,0], [1,1]]
            points[0][0] = p_min[0]
            points[0][1] = p_min[1]
            points[1][0] = p_max[0]
            points[1][1] = p_max[1]
            if debug:
                plt.imshow(proc_img[points[0][1]:points[1][1], points[0][0]:points[1][0]])
                plt.show()
            sub_img = rescale_character(proc_img[points[0][1]:points[1][1], points[0][0]:points[1][0]], height, width)    
            legend_imgs.append(cv2.resize(sub_img, (16, 16), interpolation = cv2.INTER_AREA))
            pred_img[k,] = legend_imgs[-1]
            if debug:
                plt.imshow(pred_img[k,])
                plt.show()
            k += 1
    # Get the bounds for the map
    pred_img = pred_img[0:k,]
    if pred_img.shape[0] > 0:
        preds = model.predict(pred_img)
        map_label_inds = np.argmax(preds, axis=1)
        map_labels[data_file] = [labels[k] for k in map_label_inds]
        #map_labels[data_file] = {{label_names[k]:labels[map_label_inds[k]]} for k in range(len(map_label_inds))}

        mapped_legends = np.argwhere(preds > 0.1)
        valid_legends[data_file] = list(set(mapped_legends[:,1]))
    else:
        map_labels[data_file] = []
        valid_legends[data_file] = []
    #valid_legend_labels = [labels[k] for k in valid_legends[data_file]]
    
with open(sub_dir + '_pt_legend_mapping.pkl', 'wb') as f:
    pickle.dump([map_labels, valid_legends], f)

elapsed_time = time.time() - start_time