# -*- coding: utf-8 -*-
"""
Created on Fri Sep 23 15:28:33 2022

@author: scott
"""

import numpy as np
from matplotlib import pyplot as plt
import matplotlib.patches as patches
from scipy.spatial import cKDTree
import cv2
import os
import json
import pandas as pd
import time
import random
#from metrics import feature_f_score_from_img
from tensorflow import keras
import pickle
from sklearn.cluster import DBSCAN

def process_point(n0, n1):
    if n0 > n1:
        temp = n0
        n0 = n1
        n1 = temp
    if n0 == n1:
        n1 += 1
    return n0, n1

def get_legend_bounds_xy(points):
    x0, x1 = process_point(int(points[0][0]), int(points[1][0]))
    y0, y1 = process_point(int(points[0][1]), int(points[1][1]))
    return x0 ,x1, y0, y1

def get_contour_level(contours, hierarchy, cnt_id):
    if hierarchy[0, cnt_id, 3] == -1:
        return 0
    else:
        return get_contour_level(contours, hierarchy, hierarchy[0, cnt_id, 3]) + 1

def letter_box(img):
    temp = 255-img
    rows = np.any(temp, axis=0)
    cols = np.any(temp, axis=1)
    rmin, rmax = np.where(rows)[0][[0, -1]]
    cmin, cmax = np.where(cols)[0][[0, -1]]
    return cmin, rmin, cmax + 1, rmax + 1

def rescale_character(image, height, width):
    y0, x0, y1, x1 = letter_box(image)
    if x0 == x1:
        x0 -= x0
    if y0 == y1:
        y0 -= 1
    image = image[y0: y1, x0:x1]
    im_height = image.shape[0]
    im_width = image.shape[1]
    if im_height > height or im_width > width:
        # too large 
        max_dim = max(im_height, im_width)
        sub_img = 255 * np.ones((max_dim, max_dim, 3), dtype=np.uint8)
        if im_height > im_width:
            offset = (im_height - im_width) // 2
            for k in range(3):
                sub_img[0:im_height, offset:offset + im_width, k] = image  
        else:
            offset = (im_width - im_height) // 2
            for k in range(3):
                sub_img[offset:offset + im_height, 0:im_width, k] = image
        sub_img = cv2.resize(sub_img, (16, 16), interpolation = cv2.INTER_AREA)
        #cv2.imwrite('parsed_text/' + str(ind) + '_failed.jpg', sub_img)
    else:
        x_offset = (width - im_width) // 2 
        y_offset = (height - im_height)  // 2
        sub_img = 255 * np.ones((height, width, 3), dtype=np.uint8)
        for k in range(3):
            sub_img[y_offset:y_offset + im_height, x_offset:x_offset + im_width, k] = proc_map_img[y0:y1, x0:x1]
    return sub_img

def label_code_to_string(label_code):
    if len(label_code) > 1:
        if label_code[1] == '_': # symbol represents a number or letter
            temp_str = label_code[0]
        else:
            temp_str = '_'
    else:
        temp_str = label_code
    return temp_str

with open('settings.json') as f:
    settings = json.load(f)
# The directory containing the tif and json files
sub_dir = settings['sub_dir']

data_dir = settings['base_dir'] + sub_dir + '/'
debug_sub_dirs = ['training', 'testing']
# The subdirectory under data_dir in which to store the output tifs
output_dir = settings['output_dir'] + '/'
# masking params
# The percent deviation allowed to match a color with a legend
color_range = 0.05
# The smallest contour area to be considered a legit area
min_contour_size = 50
# Turns writing the final image on or off. Saves about 1 hour of proessing when off
write_mask_image = True
# Writes color images masked with positives and negatives
write_debug_images = False
# debug_count of 0 means not in debug mode. debug_count of 1 slects the first map. debug_count > 1 selects debug_count random maps.
debug_count = 0
# Only process these legend types if debug_count > 0
debug_types = ['poly', 'rectangle', 'pt', 'point', 'line']
#debug_types = ['point']
plot_legend = False # Plot the extracted legends
verbose_time = False
ocr_width = 16
ocr_height = 16
min_cnt_length = 8

start_time = time.time()
directory = os.fsencode(data_dir)

# Build list of map names
maps = []
files = []
for file_b in os.listdir(directory):
    file = file_b.decode('UTF-8')
    files.append(file)
    if file[-4:] == 'json':
        maps.append(file[:-5])
        
# Retrieve the data from all the info files for each map and store it in data_files
data_files = {}
for cur_map in maps:
    data_files[cur_map] = {}
    map_files = [f for f in files if (f.startswith(cur_map) and len(f) > len(cur_map) + 5)]
    f = open(data_dir + cur_map + '.json', 'r')
    data_files[cur_map]['metadata'] = json.load(f)
    f.close()
    data_files[cur_map]['base_map'] = cur_map + '.tif'
    data_files[cur_map]['results'] = map_files

if debug_count > 1:
    # Randomly sample debug_count files
    keys = random.sample(list(data_files), debug_count)
    data_files = {k:data_files[k] for k in keys}
elif debug_count == 1:
    # Use the first file
    data_file = 'NV_Goldfield_318879_1987_24000_geo_mosaic'
    data_file = 'AZ_Arivaca_314329_1941_62500_geo_mosaic'
    #data_file = 'CO_Boulder_1978'
    data_file = 'AK_Bettles'
    #data_files = {list(data_files.keys())[0]: data_files[list(data_files.keys())[0]]}
    data_files = {data_file: data_files[data_file]}
else:
    # Use them all
    pass

# Get the bounds for the map
bounds_df = pd.read_csv('map_bounds_' + sub_dir + '.csv')
bounds_df = bounds_df.set_index(bounds_df.columns[0])
bounds = bounds_df.to_dict(orient='index')

# Load the OCR model and labels
model = keras.models.load_model('legend_recognition_16x16_97_prod.h5')
with open('labels_95_prod.pkl', 'rb') as fp:  
    labels = pickle.load(fp)
labels.append(' ')
with open(sub_dir + '_pt_legend_mapping.pkl', 'rb') as f:
    map_labels, valid_legends = pickle.load(f)

# Create a dictionary of ambiguous letters to deal with OCR issues
ambiguous_letters = {
    '3' : 'a', # This is an issue with my OCR approach which should be resolved through better training
    '8' : 'a', # Same as above
    '0' : 'o',
    'O' : 'o',
    'Q' : 'o',
    '1' : 'l'
}
ins = '380OQ1'
outs = 'aaoool'
trans = str.maketrans(ins, outs)

# The main processing loop
results = []
# Go through each map
# Use the below to delete specified maps in case the process is interrupted
# keys= list(data_files.keys())
# keys = [k for k in keys if k <'W']
# for key in keys:
#     del data_files[key]
dup_legends = []
for data_file in data_files:
    print(data_file)
    # Training

    # Validation
    # 8.2 hours with image output
    # Iterate through all the legends for a given map
    legend_items = data_files[data_file]['metadata']['shapes']
    items_to_delete = []
    items = []
    for k in range(len(legend_items)):
        if legend_items[k]['label'] in items:
            items_to_delete.append(k)
        else:
            items.append(legend_items[k]['label'])
    items_to_delete.reverse()
    for k in items_to_delete:
        legend_items.pop(k)
    legend_types = set([legend['label'].split('_')[-1] for legend in legend_items])
    if len(legend_types & set(debug_types)) > 0:
        img = cv2.imread(data_dir + data_files[data_file]['base_map'])
        #size = np.product(np.shape(img)) / 3
        shape = img.shape
        map_x0 = int(bounds[data_file + '_thumb.tif']['x0'] * shape[1])
        map_x1 = int(bounds[data_file + '_thumb.tif']['x1'] * shape[1])
        map_y0 = int(bounds[data_file + '_thumb.tif']['y0'] * shape[0])
        map_y1 = int(bounds[data_file + '_thumb.tif']['y1'] * shape[0])
        map_img = img[map_y0:map_y1, map_x0:map_x1, :].copy()
        size = np.product(np.shape(map_img)) / 3
        # Pass 1
        # all_colors = np.unique(map_img.reshape(-1, map_img.shape[2]), axis=0) # Get all unique colors.
        similar_legends = {}
        legend_colors = {}
        legend_by_colors = {}
        color_by_color_256 = {}
        processed_legend = []
        for item in legend_items:
            x0, x1, y0, y1 = get_legend_bounds_xy(item['points'])
            legend_img = img[y0:y1, x0:x1, :]
            if item['label'][-3:] == '_pt' or item['label'][-5:] == '_line':
                centers = np.array([[0, 0, 0]], dtype=np.uint8)
            else:
                centers = np.array([[int(np.median(legend_img[:,:,0])), int(np.median(legend_img[:,:,1])), int(np.median(legend_img[:,:,2]))]])
            item['color'] = centers[0]
            legend_colors[item['label']] = item['color']
            temp_color = item['color'].astype(np.int32)
            color_256 = temp_color[0] * 256 *256 + temp_color[1] * 256 + temp_color[2]
            if color_256 in legend_by_colors:
                legend_by_colors[color_256].append(item['label'])
            else:
                legend_by_colors[color_256] = [item['label']]
                color_by_color_256[color_256] = centers
        
        most_similar = 0
        colors = np.ones((1,3)) * 50 # Force a dark gray to account for blacks and dark grays
        for item in legend_items:
            centers = item['color']
            colors = np.concatenate((colors, np.resize(centers, (1,3))))
            lower = np.round(centers * (1 - color_range))
            upper = np.round(centers * (1 + color_range))
            # Pass 1
            # Create a dictionary of similar legend colors
            for legend_color in legend_colors:
                temp_center = np.reshape(legend_colors[legend_color], (1, 1, 3))
                if cv2.inRange(temp_center, lower, upper)[0, 0] > 0: # colors overlap
                    if item['label'] in similar_legends:
                        similar_legends[item['label']].append(legend_color)
                    else:
                        similar_legends[item['label']] = [legend_color]
                    # if legend_color in similar_legends:
                    #     similar_legends[legend_color].append(item['label'])
                    # else:
                    #     similar_legends[legend_color] = [item['label']]
                    if len(similar_legends[item['label']]) > most_similar:
                        most_similar = len(similar_legends[item['label']])
                    # if len(similar_legends[legend_color]) > most_similar:
                    #     most_similar = len(similar_legends[legend_color])
        colors = np.unique(colors, axis=0).astype(np.uint8)
        
        # Combine similar colors
        if False: # Turn the similar color combination on or off
            close_colors = cKDTree(colors).query_pairs(r=10) # Find all colors within r of eachother
            colors_to_delete = []
            for k in close_colors:
                color_0 = colors[k[0],:]
                color_1 = colors[k[1],:]
                colors = np.vstack((colors, color_0 // 2 + color_1 // 2))
                colors_to_delete.append(k[0])
                colors_to_delete.append(k[1])
                if debug_count > 0 and plot_legend:
                    fig = plt.figure(figsize=(4, 4), dpi=80)
                    ax = fig.add_subplot(111)
                    rect = patches.Rectangle((0, 0), 1, 0.5, linewidth=1, edgecolor=color_0 / 255, facecolor=color_0 / 255)
                    ax.add_patch(rect)
                    ax.text(0.25, 0.25, str(color_0), va='center', ha='center')
                    rect = patches.Rectangle((0, 0.5), 1, 0.5, linewidth=1, edgecolor=color_1 / 255, facecolor=color_1 / 255)
                    ax.add_patch(rect)
                    ax.text(0.25, 0.75, str(color_1), va='center', ha='center')
                    plt.show()
            colors_to_delete.sort(reverse=True)
            for k in colors_to_delete:
                colors = np.delete(colors, k, axis=0)
        # If a map has no poly features, there will only be the two inserted colors. We need to add another
        num_colors = colors.shape[0]
        if num_colors < 3:
            #colors = np.append(colors, np.ones((1,3), dtype=np.uint8) * 200, axis=0)
            colors = np.array([[0, 0, 0], [50, 50, 50], [224, 224, 224]], dtype=np.uint8)
            # map_img = img[map_y0:map_y1, map_x0:map_x1, :].copy()
            #cv2.imwrite('bw_test.tif', img[1500:2500, 1000:2000, :])
            #cv2.imwrite('map_img.tif', map_img)
            #cv2.imwrite('img.tif', img)
            hsv = cv2.cvtColor(map_img, cv2.COLOR_BGR2HSV)
            # define range of blue color in HSV
            black = np.array([0,0,0])
            dark_gray = np.array([150, 150, 200])
            # Threshold the HSV image to get only blue colors
            mask = 255 - cv2.inRange(hsv, black, dark_gray)
            for k in range(3):
                map_img[:, :, k] = mask
            # Bitwise-AND mask and original image
            #map_img = cv2.bitwise_and(map_img,map_img, mask= mask)
            # #cv2.imwrite('gray_map.tif', map_img)
        # Plot the legend colors
        if debug_count > 0 and plot_legend:
            fig = plt.figure(figsize=(most_similar / 2, len(legend_colors) / 4), dpi=80)
            ax = fig.add_subplot(111)
            ax.set_ylim([0, len(legend_colors) / 4])
            ax.set_xlim([0, most_similar / 2])
            ax.text(most_similar / 4, len(legend_colors) / 4, data_file, va='top', ha='center')
            y_pos = len(legend_colors) / 4 - 1
            for item in legend_items:
                color = np.array(item['color']) / 255
                rect = patches.Rectangle((0, y_pos), 0.5, 0.25, linewidth=1, edgecolor=color, facecolor=color)
                ax.add_patch(rect)
                ax.text(0.25, y_pos + 0.125, item['label'][0:3], va='center', ha='center')
                x_pos = 0.5
                if item['label'] in similar_legends:
                    for legend in similar_legends[item['label']]:
                        color = legend_colors[legend] / 255
                        rect = patches.Rectangle((x_pos, y_pos), 0.5, 0.25, linewidth=1,edgecolor='black',facecolor=color)
                        ax.add_patch(rect)
                        ax.text(x_pos + 0.25, y_pos + 0.125, legend[0:3], va='center', ha='center')
                        x_pos += 0.5
                y_pos -= 0.25
            plt.axis('off')
            plt.show()
        
        # Convert the base map to one with a color map matching the legend
        img_mapped = cv2.fastNlMeansDenoisingColored(map_img, None, 10, 10, 7, 21) # Denoise the input image.
        img_mapped = colors[cKDTree(colors).query(img_mapped, k=1)[1]]        
        
        if debug_count > 0:
            cv2.imwrite(data_file + '_mapped.tif', img_mapped)
        # Get the darkest color to remove
        darkest_color = colors[np.argmin(np.sum(colors, axis = 1)), :]
        darkest_color_2d = darkest_color[0]*256*256 + darkest_color[1]*256 + darkest_color[2]
        darkest_mask = np.round(cv2.inRange(img_mapped, darkest_color, darkest_color) / 255).astype(np.uint8)
        
        # Remove darkest lines using inpaint
        # Need to chunk the image since inpaint seems to operate on O(N2) or worse
        inpaint_start = time.time()
        chunk_size = 100
        img_mapped_infilled = np.zeros(img_mapped.shape, dtype=np.uint8)
        for x in range(img_mapped.shape[1] // chunk_size):
            x_range = range(x * chunk_size, (x + 1) * chunk_size)
            for y in range(img_mapped.shape[0] // chunk_size):
                y_range = range(y * chunk_size, (y + 1) * chunk_size)
                img_mapped_infilled[np.ix_(y_range, x_range, range(3))] = cv2.inpaint(img_mapped[np.ix_(y_range, x_range, range(3))],darkest_mask[np.ix_(y_range, x_range)],3,cv2.INPAINT_TELEA)
            y_range = range((img_mapped.shape[0] // chunk_size) * chunk_size, img_mapped.shape[0])
            img_mapped_infilled[np.ix_(y_range, x_range, range(3))] = cv2.inpaint(img_mapped[np.ix_(y_range, x_range, range(3))],darkest_mask[np.ix_(y_range, x_range)],3,cv2.INPAINT_TELEA)
        for y in range(img_mapped.shape[0] // chunk_size):
            x_range = range((img_mapped.shape[1] // chunk_size) * chunk_size, img_mapped.shape[1])
            y_range = range(y * chunk_size, (y + 1) * chunk_size)
            if len(x_range) > 0:
                img_mapped_infilled[np.ix_(y_range, x_range, range(3))] = cv2.inpaint(img_mapped[np.ix_(y_range, x_range, range(3))],darkest_mask[np.ix_(y_range, x_range)],3,cv2.INPAINT_TELEA)
        y_range = range((img_mapped.shape[0] // chunk_size) * chunk_size, img_mapped.shape[0])
        if len(x_range) > 0 and len(y_range) > 0:
            img_mapped_infilled[np.ix_(y_range, x_range, range(3))] = cv2.inpaint(img_mapped[np.ix_(y_range, x_range, range(3))],darkest_mask[np.ix_(y_range, x_range)],3,cv2.INPAINT_TELEA)
        img_mapped_infilled = colors[cKDTree(colors).query(img_mapped_infilled, k=1)[1]] 
        if debug_count > 0:
            cv2.imwrite('infill.tif', img_mapped_infilled)
            cv2.imwrite('infill_pre_img_mapped.tif', img_mapped)
            cv2.imwrite('map_img.tif', map_img)
            print(time.time()-inpaint_start)
        
        temp = img_mapped.astype(np.uint32)
        #img_mapped_2d = temp[:, :, 0] * 256 * 256 + temp[:, :, 1] * 256 + temp[:, :, 2]
        img_mapped_infilled = colors[cKDTree(colors).query(img_mapped_infilled, k=1)[1]] 
        temp = img_mapped_infilled.astype(np.uint32)
        img_mapped_infilled_2d = temp[:, :, 0] * 256 * 256 + temp[:, :, 1] * 256 + temp[:, :, 2]
        
        ####### Point and line processing
        proc_map_img = 255 - cv2.inRange(map_img, (0, 0, 0), (64, 64, 64))
        kernel = np.ones((5, 5), np.uint8)
        line_mask = 1 - cv2.dilate(proc_map_img, kernel, iterations=1) // 255
        darkest_mask = 1 - proc_map_img // 255
        if debug_count > 0:
            cv2.imwrite('darkest_mask.tif', darkest_mask * 255)
            cv2.imwrite('line_mask.tif', line_mask * 255)
        ########## End Line features
        
        proc_map_img = 255 - darkest_mask * 255
        #cv2.imwrite('custom_mapped_image.tif', img_mapped)
        #cv2.imwrite('custom_darkest_image.tif', proc_map_img)
    
        contours, hierarchy = cv2.findContours(proc_map_img,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        contour_bounds = []
        #non_line_cnts = []
        for cnt in contours:
            x,y,w,h = cv2.boundingRect(cnt)
            
            #bound the images
            area = w * h
            if area < 2000 and area > 100:
                #non_line_cnts.append(cnt)
                cv2.drawContours(line_mask, [cnt], 0, color=0, thickness=cv2.FILLED)
                #cv2.rectangle(proc_map_img ,(x,y),(x+w,y+h),(192,192,0),1)
                #cv2.rectangle(map_img ,(x,y),(x+w,y+h),(192,192,0),1)
                contour_bounds.append({'x':x, 'y':y,'w':w, 'h':h, 'area':area})
        contour_df = pd.DataFrame(contour_bounds)
        #cv2.drawContours(line_mask, non_line_cnts, 0, color=0, thickness=cv2.FILLED)
        
        img_width = map_img.shape[1]
        img_height = map_img.shape[0]
        pt_results = []
        
        # Find clusters of letters which are likely to be multicharacter legends
        db = DBSCAN(eps=24, min_samples=2)
        clusters = db.fit_predict(contour_df[['x', 'y']])
        contour_df['cluster'] = clusters
        
        pred_img = 255 * np.ones((len(contour_df), ocr_height, ocr_width, 3))
        if len(contour_df) > 0:
            for ind, row in contour_df.iterrows():
                x, y, w, h = row[['x', 'y', 'w', 'h']]
                y0 = np.clip(y, 0, img_height - 1)
                y1 = np.clip(y + h, 0 , img_height - 1)
                x0 = np.clip(x, 0, img_width - 1)
                x1 = np.clip(x + w + 2, 0, img_width - 1)
                if x0 == x1:
                    x0 -= x0
                if y0 == y1:
                    y0 -= 1
                sub_img = rescale_character(proc_map_img[y0:y1, x0:x1], ocr_height, ocr_width)    
                pred_img[ind, :, :, :] = sub_img
            preds = model.predict(pred_img)
            
            # Identify possible labels with predicted letters
            for k in range(3):
                texts = [labels[k] for k in np.argsort(preds, axis=1)[:, -(k + 1)]]
                confs = np.sort(preds, axis=1)[:,-(k + 1)]
                contour_df['label_' + str(k)] = texts
                contour_df['conf_' + str(k)] = confs
                
            for ind, row in contour_df.iterrows():
                pred = preds[ind,:]
                legend_ind = np.argmax(pred)
                if legend_ind in valid_legends[data_file]:
                    legend = labels[legend_ind]
                    conf = pred.max() * 100
                    alt_legend = labels[np.argsort(pred)[-2]]
                    alt_conf = preds[ind, np.argsort(pred)[-2]]
                    x, y, w, h = row[['x', 'y', 'w', 'h']]
                
                    font_color = (0, conf * 2, conf * 2)
                    if len(legend) > 1 and legend[1] == '_':
                        clean_text = legend[0]
                    else:
                        clean_text = legend
                    pt_results.append({'map':data_file, 'x':x, 'y':y,  
                                    'w':w, 'h':h, 
                                    'a':w * h, 'legend_id':legend, 'conf': np.max(pred), 'alt_legend':alt_legend, 'alt_conf':alt_conf, 'index':ind})
            # Associate labels with contours
            label_results = []
            for k in range(contour_df['cluster'].max() + 1):
                temp_df = contour_df[contour_df['cluster']  == k].sort_values('x')
                temp_df['x1'] = temp_df['x'] + temp_df['w']
                temp_df['y1'] = temp_df['y'] + temp_df['h']
                temp_str_0 = ''
                temp_str_1 = ''
                for ind, row in temp_df.iterrows():
                    temp_str_0 += label_code_to_string(row['label_0'])
                    temp_str_1 += label_code_to_string(row['label_1'])
                x, y = temp_df[['x', 'y']].min()
                x1, y1 = temp_df[['x1', 'y1']].max()
                cv2.rectangle(proc_map_img ,(x,y),(x1,y1),(0,0,192),1)
                cv2.rectangle(map_img ,(x,y),(x1,y1),(0,0,192),1)
            #    cv2.putText(map_img, temp_str_0 + '/' + temp_str_1, (x, y), font, font_scale, font_color, thickness=thickness)
            #    cv2.putText(proc_map_img, temp_str, (x, y), font, font_scale, font_color, thickness=thickness)
                label_results.append({'x':x, 'y':y, 'w':x1-x, 'h':y1-y, 'cluster':k, 
                                      'label_0':temp_str_0, 'label_1':temp_str_1, 
                                      'label_0_trans':temp_str_0.translate(trans).replace('_', '').replace(' ', '').lower()})
    
            for ind, row in contour_df[contour_df['cluster'] == -1].iterrows():
                x, y = row[['x', 'y']]
                temp_str_0 = label_code_to_string(row['label_0'])
                temp_str_1 = label_code_to_string(row['label_1'])
            #    cv2.putText(map_img, temp_str, (x, y), font, font_scale, font_color, thickness=thickness)
            #    cv2.putText(proc_map_img, row['label_0'], (x, y), font, font_scale, font_color, thickness=thickness)
                label_results.append({'x':x, 'y':y, 'w':x1-x, 'h':y1-y, 'cluster':k, 'label_0':temp_str_0, 'label_1':temp_str_1, 
                'label_0_trans':temp_str_0.translate(trans).replace('_', '').replace(' ', '').lower()})
    
            label_df = pd.DataFrame(label_results)
            label_df['label_0_trans'] = label_df['label_0_trans'].fillna('')
        pt_df = pd.DataFrame(pt_results)
        ##################### End point or line feature preprocessing
    
        # Pass 2 
        # Process each legend and create a mask
        for color_2d in legend_by_colors:
            # Since colors are duplicated and the contouring is time-consuming contour and process once per color
            item_start_time = time.time()
            centers = color_by_color_256[color_2d] 
            print('Dominant color is: bgr({})'.format(centers[0].astype(np.int32)))
            if color_2d != darkest_color_2d: # Poly features
                if 'poly' in debug_types:
                    map_mask = (img_mapped_infilled_2d == color_2d).astype(np.uint8)
                    contours, hierarchy = cv2.findContours(map_mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
                    poly_mask = np.zeros((img.shape[0], img.shape[1])).astype(np.uint8)
                    # The morphology improves processing speed but at too great a performance cost
                    #kernel = np.ones((5,5),np.uint8)
                    #map_mask = cv2.morphologyEx(map_mask, cv2.MORPH_CLOSE, kernel)
                    if verbose_time:
                        step_time = time.time() - item_start_time
                        print(' Get contours: ' + str(step_time))
                    if len(contours) > 0:
                        temp_mask = np.zeros((map_mask.shape[0], map_mask.shape[1])).astype(np.uint8)
                        cnt_list = []
                        for k in range(len(contours)):
                            cnt = contours[k]
                            hier = hierarchy[0, k,:]
                            x,y,w,h = cv2.boundingRect(cnt)
            
                            #bound the images
                            if cnt.shape[0] >= min_cnt_length:
                                area = w * h
                                level = get_contour_level(contours, hierarchy, k)
                                cnt_list.append({'id':k, 'contour_length':cnt.shape[0], 'rough_area':area, 'area': cv2.contourArea(cnt), 'perimeter': cv2.arcLength(cnt, True), 'parent':hier[3], 'level':level})
                                # if area > min_contour_size:
                                #     perimeter = cv2.arcLength(cnt, True)
                                #     area = cv2.contourArea(cnt)
                        if len(cnt_list) > 0:
                            cnt_df = pd.DataFrame(cnt_list).sort_values('level')
                            cnt_df['lineiness'] = cnt_df['perimeter'] / (cnt_df['area'] + 1)
                            cnt_df['draw'] = ''
                            for k, row in cnt_df.iterrows():
                                area = row['area']
                                lineiness = row['lineiness']
                                level = row['level']
                                cnt = contours[int(row['id'])]
                                if lineiness < 1 and area > min_contour_size * (100 ** (level)) and area < 1000000:
                                    if level % 2 == 0:
                                        cv2.drawContours(temp_mask, [cnt], 0, color=1, thickness=cv2.FILLED)
                                        cv2.drawContours(temp_mask, [cnt], 0, color=1, thickness=2)
                                        cnt_df.at[k, 'draw'] = 'yes'
                                    else:
                                        cv2.drawContours(temp_mask, [cnt], 0, color=0, thickness=cv2.FILLED)
                                        #cv2.drawContours(temp_mask, [cnt], 0, color=1, thickness=2)
                                        cnt_df.at[k, 'draw'] = 'erase'    
                            
                                else:
                                    if level > 0:
                                        #cv2.drawContours(temp_mask, [cnt], 0, color=1, thickness=cv2.FILLED)
                                        #cv2.drawContours(temp_mask, [cnt], 0, color=1, thickness=2)
                                        cnt_df.at[k, 'draw'] = 'ignore'        
                                    else:
                                        cnt_df.at[k, 'draw'] = 'ignore'      
                            poly_mask[map_y0:map_y1, map_x0:map_x1] = temp_mask
                            if verbose_time:
                                step_time = time.time() - item_start_time
                                print(' process_contours: ' + str(step_time))
                        else:
                            poly_mask = np.zeros((img.shape[0], img.shape[1])).astype(np.uint8)
                            centers = [[0., 0., 0.]]                            
                    else: # Zero sized legend image
                        poly_mask = np.zeros((img.shape[0], img.shape[1])).astype(np.uint8)
                        centers = [[0., 0., 0.]]
            ############################## Point and line features
            else:   # Darkest color assume to be point or line features
                #darkest_mask = np.round(cv2.inRange(img_mapped, darkest_color, darkest_color) / 255).astype(np.uint8)
                #### HSV approach
                # hsv = cv2.cvtColor(map_img, cv2.COLOR_BGR2HSV)
                # black = np.array([0,0,0])
                # dark_gray = np.array([150, 150, 200])
                # # Threshold the HSV image to get only gray colors
                # darkest_mask = cv2.inRange(hsv, black, dark_gray) // 255
                # cv2.imwrite('darkest_mask1.tif', darkest_mask * 255)
                ###########
                ########## Line features
                # kernel = np.ones((4,4),np.uint8)
                # open_sl = cv2.dilate(darkest_mask, kernel, iterations=1)
                # short = 5
                # long = 7
                # short = 6
                # long = 7
                # kernel = np.ones((short,long),np.uint8)
                # open_sl = cv2.morphologyEx(open_sl, cv2.MORPH_OPEN, kernel)
                # kernel = np.ones((long,short),np.uint8)
                # open_ls = cv2.morphologyEx(darkest_mask, cv2.MORPH_OPEN, kernel)
    
                # line_mask = open_sl + open_ls
                pass
            if verbose_time:
                step_time = time.time() - item_start_time
                print(' Init: ' + str(step_time))
            for legend in legend_by_colors[color_2d]:
                pt_ind = 0
                for item in legend_items:
                    if item['label'] == legend:
                        break
                    if item['label'].split('_')[-1] == 'pt' or item['label'].split('_')[-1] == 'point':
                        pt_ind += 1
                print(data_file + ' ' + item['label'])
                x0, x1, y0, y1 = get_legend_bounds_xy(item['points'])
                legend_type = item['label'].split('_')[-1]
                # If in debug mode, only look at certain types of legends
                if (legend_type in debug_types):
                    # Extract the legend image from the map
                  
                    if legend_type == 'poly' or legend_type == 'rectangle':
                        if len(legend_by_colors[color_2d]) == 1:
                            mask = poly_mask
                        else: # multiple legends for color
                            mask = poly_mask.copy()
                            other_legends = legend_by_colors[color_2d].copy()
                            other_legends.remove(legend)
                            other_legends = [leg.lower() for leg in other_legends]
                            contours, hierarchy = cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
                            for cnt in contours:
                                if cv2.contourArea(cnt) > 0:
                                   x,y,w,h = cv2.boundingRect(cnt)
                                   temp_df = label_df[(label_df['x'] > x) & (label_df['x'] < x + w)
                                                      & (label_df['y'] > y) & (label_df['y'] < y + h)]
                                   for tind, trow in temp_df.iterrows():
                                       if trow['label_0_trans'] + '_poly' in other_legends: # erase the contour
                                           print('Erase contour! ' + legend)
                                           cv2.drawContours(mask, [cnt], 0, color=0, thickness=cv2.FILLED)
                                           break
                    elif legend_type == 'pt' or legend_type == 'point':
                        mask = np.zeros((img.shape[0], img.shape[1])).astype(np.uint8)
                        if size < 80000000: # Skip files that are too large or crash your computer!
                            map_label = map_labels[data_file][pt_ind]
                            if len(pt_df) > 0:
                                legend_df = pt_df[(pt_df['legend_id'] == map_label)] #  | (pt_df['alt_legend'] == map_label)
                                # Calculate match to actual
                                temp_mask = np.zeros((img_height, img_width), dtype=np.uint8)
                                mask = np.zeros((img.shape[0], img.shape[1]), dtype=np.uint8)
                                for ind, row in legend_df.iterrows():
                                    x = row['x'] + row['w'] // 2 
                                    y = row['y'] + row['h'] // 2
                                    temp_mask[y, x] = 1
                                mask[map_y0:map_y1, map_x0:map_x1] = temp_mask
                        else:
                            print(data_files[data_file]['base_map'] + ' is too large. Skipping pt analysis')
    
                    elif legend_type =='line':
                        mask = np.zeros((img.shape[0], img.shape[1])).astype(np.uint8)
                        mask[map_y0:map_y1, map_x0:map_x1] = line_mask
                    else:
                        print('Missing legend type: ' + legend_type)
                    
                    # If this is training data, calculate the performance
                    if sub_dir in debug_sub_dirs:
                        # Get the truth result provided for the training data
                        actual = cv2.imread(data_dir + data_file + '_' + item['label'] + '.tif')
                        # Get the number of pixels in the legend area for this image
                        num_actual = np.sum(actual[:, :, 0])
                        # Gather statistics on the accuracy of our prediction
                        #if legend_type == 'poly':
                        if True:
                            num_correct_positive = np.sum(np.logical_and(actual[:, :, 0], mask))
                            num_false_positive = np.sum(np.logical_and(np.logical_not(actual[:, :, 0]), mask))
                            num_false_negative = np.sum(np.logical_and(actual[:, :, 0], np.logical_not(mask)))
                            num_correct_negative = np.sum(np.logical_and(np.logical_not(actual[:, :, 0]), np.logical_not(mask)))
                            if num_correct_positive + num_false_positive > 0:
                                precision = (num_correct_positive / (num_correct_positive + num_false_positive))
                            else:
                                precision = 0.0
                            if num_correct_positive + num_false_negative > 0:
                                recall = (num_correct_positive / (num_correct_positive + num_false_negative))
                            else:
                                recall = 0.0
                            if precision + recall > 0:
                                f_score = 2 * precision * recall / (precision + recall)
                            else:
                                f_score = 0.0
    
                        # if legend_type == 'pt' or legend_type == 'line':
                        #     mask1 = np.zeros((img.shape[0], img.shape[1], 3), dtype=np.uint8)
                        #     for k in range(3):
                        #         mask1[:, :, k] = mask
                        #     precision, recall, f_score = feature_f_score_from_img(img, mask1, actual, item['label'], legend_json_path=None, min_valid_range=.25, difficult_weight=None, set_false_as=None, plot=False, verbose = False)
                        if verbose_time:
                            step_time = time.time() - item_start_time
                            print(' calc_stats: ' + str(step_time))
                            print(str(f_score))
    
                        # Gather the results
                        results.append({'image':data_file, 'legend':item['label'], 'size':size, 'num_actual':num_actual, 
                                        'precision':precision, 'recall': recall, 'f_score': f_score,
                                        'dominant_color_bgr':centers[0], 'legend_type':legend_type, 'elapsed_seconds':time.time()-start_time})
        
                        if debug_count == 1 and plot_legend: # Plot the legend
                            #for item in legend_items:
                            x0, x1, y0, y1 = get_legend_bounds_xy(item['points'])
                            legend_img = img[y0:y1, x0:x1, :]
                            fig, ax = plt.subplots()
                            ax.imshow(cv2.cvtColor(np.concatenate((legend_img, legend_img), axis=1), cv2.COLOR_BGR2RGB))
                            color = ([centers[0][2]/255, centers[0][1]/255, centers[0][0]/255])
                            rect = patches.Rectangle((legend_img.shape[1], 0), legend_img.shape[1], legend_img.shape[0], linewidth=1, edgecolor=color, facecolor=color)
                            ax.add_patch(rect)
                            legend_height = legend_img.shape[0]
                            plt.text(legend_img.shape[1], legend_height * 0.2, data_file)
                            plt.text(legend_img.shape[1], legend_height * 0.5, item['label'])
                            plt.text(legend_img.shape[1], legend_height * 0.8, str(centers[0]))
                            plt.axis('off')
                            plt.show()
                        if write_debug_images and sub_dir in debug_sub_dirs:
                            img_g = np.logical_and(actual[:, :, 0], mask).astype(np.uint8) * 255
                            img_g += img_g + np.logical_and(np.logical_not(actual[:, :, 0]), np.logical_not(mask)).astype(np.uint8) * 128
                            img_r = np.logical_and(np.logical_not(actual[:, :, 0]), mask).astype(np.uint8) * 128
                            img_r += np.logical_and(actual[:, :, 0], np.logical_not(mask)).astype(np.uint8) * 255
                            temp = np.zeros(np.shape(img), dtype=np.uint8)
                            temp[:,:,1] = img_g
                            temp[:,:,2] = img_r
                            cv2.imwrite(data_dir + output_dir + data_file + '_' + item['label'] + '_results.tif', temp)
                    if write_mask_image and legend_type in debug_types:
                        cv2.imwrite(data_dir + output_dir + data_file + '_' + item['label'] + '.tif', mask)
                        if verbose_time:
                            step_time = time.time() - item_start_time
                            print(' write_mask: ' + str(step_time))
    
        if sub_dir in debug_sub_dirs:
            # Convert the results into a DataFrame and save them
            df = pd.DataFrame(results)
            df['index'] = df['image'] + '_' + df['legend']
            df = df.set_index('index')
            df.to_csv('training_results_v4.csv')
            print(df[['legend_type', 'f_score']].groupby('legend_type').median())
    
        # Finish the loop iteration for a map
        print(time.time() - start_time)

end_time = time.time()
elapsed_time = end_time - start_time
print(elapsed_time)