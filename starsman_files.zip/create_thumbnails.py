# -*- coding: utf-8 -*-
"""
Created on Wed Sep 28 13:53:32 2022

@author: scott
"""

import os
import json
import cv2

with open('settings.json') as f:
    settings = json.load(f)
# The directory containing the tif and json files
sub_dir = settings['sub_dir']

data_dir = settings['base_dir'] + sub_dir + '/'

directory = os.fsencode(data_dir)

# create necessary directories
if not os.path.exists(data_dir + 'output'):
    os.makedirs(data_dir + 'output')
if not os.path.exists(data_dir + 'thumbnails'):
    os.makedirs(data_dir + 'thumbnails')
if not os.path.exists(data_dir + 'thumbnails/contours'):
    os.makedirs(data_dir + 'thumbnails/contours')
    
# Build list of map names
maps = []
files = []
for file_b in os.listdir(directory):
    file = file_b.decode('UTF-8')
    files.append(file)
    if file[-4:] == 'json':
        maps.append(file[:-5])
        
# Retrive the data from all the info files for each map and store it in data_files
data_files = {}
for cur_map in maps:
    data_files[cur_map] = {}
    map_files = [f for f in files if (f.startswith(cur_map) and len(f) > len(cur_map) + 5)]
    f = open(data_dir + cur_map + '.json', 'r')
    data_files[cur_map]['metadata'] = json.load(f)
    f.close()
    data_files[cur_map]['base_map'] = cur_map + '.tif'
    data_files[cur_map]['results'] = map_files
    
for data_file in data_files:
    print(data_file)
    img = cv2.imread(data_dir + data_files[data_file]['base_map'])
    img_resized = cv2.resize(img, (512, 512), interpolation = cv2.INTER_AREA)
    cv2.imwrite(data_dir + 'thumbnails/' + data_file + '_thumb.tif', img_resized)
